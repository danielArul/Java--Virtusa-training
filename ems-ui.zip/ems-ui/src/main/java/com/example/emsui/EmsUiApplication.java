package com.example.emsui;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmsUiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmsUiApplication.class, args);
	}

}
